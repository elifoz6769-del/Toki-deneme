rootProject.name = "TokiBecayis"
include(":app")
